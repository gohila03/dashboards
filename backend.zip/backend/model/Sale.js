// backend/models/Sale.js
const mongoose = require('mongoose');

const saleSchema = new mongoose.Schema({
  month: String,
  year: Number,
  category: String,
  sales: Number,
  region: String
},{collection:'Sale'});

module.exports = mongoose.model('Sale', saleSchema);
