// backend/routes/sales.js
const express = require('express');
const Sale = require('../model/Sale.js');
const router = express.Router();

// Get all sales data
router.get('/', async (req, res) => {
  try {
    const sales = await Sale.find({});
    res.json(sales);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
