// backend/server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const salesRouter = require('./route/Sales.js');

const app = express();
app.use(cors());
app.use(express.json());


mongoose.connect('mongodb+srv://gohilasasikumar:Gohila2003@cluster0.y33ja.mongodb.net/ysquare')
.then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));

app.use('/api/sales', salesRouter);

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
