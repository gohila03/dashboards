// frontend/src/components/PieChart.js
import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const PieChart = ({ data }) => {
  const chartRef = useRef();
  const legendRef = useRef();

  useEffect(() => {
    // Clear existing chart elements
    d3.select(chartRef.current).selectAll('*').remove();
    d3.select(legendRef.current).selectAll('*').remove();

    const width = 300;
    const height = 300;
    const radius = Math.min(width, height) / 2;

    // Calculate sales by region
    const regionSales = d3.rollups(
      data,
      (v) => d3.sum(v, (d) => d.sales),
      (d) => d.region
    );

    const totalSales = d3.sum(regionSales, (d) => d[1]);

    const color = d3.scaleOrdinal(d3.schemeCategory10);

    const pie = d3.pie().value((d) => d[1]);

    const arc = d3.arc().innerRadius(0).outerRadius(radius);
    const labelArc = d3.arc().innerRadius(radius * 0.6).outerRadius(radius * 0.9);

    const svg = d3
      .select(chartRef.current)
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${width / 2}, ${height / 2})`);

    const arcs = svg
      .selectAll('path')
      .data(pie(regionSales))
      .enter()
      .append('g')
      .attr('class', 'arc');

    // Draw pie segments
    arcs
      .append('path')
      .attr('d', arc)
      .attr('fill', (d) => color(d.data[0]));

    // Add labels for each segment
    arcs
      .append('text')
      .attr('transform', (d) => `translate(${labelArc.centroid(d)})`)
      .attr('dy', '0.35em')
      .style('text-anchor', 'middle')
      .style('font-size', '12px')
      .text((d) => {
        const percentage = ((d.data[1] / totalSales) * 100).toFixed(1);
        return `(${percentage}%)`;
      });

    // Tooltip for hover effect
    const tooltip = d3
      .select('body')
      .append('div')
      .attr('class', 'tooltip')
      .style('position', 'absolute')
      .style('padding', '8px')
      .style('background', '#ddd')
      .style('border-radius', '4px')
      .style('visibility', 'hidden');

    arcs
      .on('mouseover', (event, d) => {
        const [x, y] = d3.pointer(event);
        tooltip
          .style('top', `${y}px`)
          .style('left', `${x +20}px`)
          .style('visibility', 'visible')
          .html(
            `<strong>Region:</strong> ${d.data[0]}<br><strong>Sales:</strong> $${d.data[1]}`
          );
      })
      .on('mousemove', (event) => {
        const [x, y] = d3.pointer(event);
        tooltip.style('top', `${y}px`).style('left', `${x + 20}px`);
      })
      .on('mouseout', () => {
        tooltip.style('visibility', 'hidden');
      });

    // Add legend
    const legend = d3.select(legendRef.current)
      .attr('width', width)
      .attr('height', regionSales.length * 20); // Adjust height based on items

    legend
      .selectAll('rect')
      .data(regionSales)
      .enter()
      .append('rect')
      .attr('x', 10)
      .attr('y', (d, i) => i * 20)
      .attr('width', 12)
      .attr('height', 12)
      .attr('fill', (d) => color(d[0]));

    legend
      .selectAll('text')
      .data(regionSales)
      .enter()
      .append('text')
      .attr('x', 30)
      .attr('y', (d, i) => i * 20 + 10)
      .text((d) => d[0])
      .attr('font-size', '12px')
      .attr('alignment-baseline', 'middle');
  }, [data]);

  return (
    <div>
      <svg ref={chartRef}></svg>
      <svg ref={legendRef} style={{ marginTop: '10px' }}></svg>
    </div>
  );
};

export default PieChart;
