// frontend/src/components/BarChart.js
import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const BarChart = ({ data }) => {
  const chartRef = useRef();

  useEffect(() => {
    // Clear any previous chart elements
    d3.select(chartRef.current).selectAll('*').remove();

    const width = 600;
    const height = 300;
    const margin = { top: 20, right: 20, bottom: 40, left: 50 };

    const svg = d3
      .select(chartRef.current)
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Calculate total sales per category
    const categorySales = d3.rollups(
      data,
      (v) => d3.sum(v, (d) => d.sales),
      (d) => d.category
    );

    const xScale = d3
      .scaleBand()
      .domain(categorySales.map((d) => d[0]))
      .range([0, width])
      .padding(0.2);

    const yScale = d3
      .scaleLinear()
      .domain([0, d3.max(categorySales, (d) => d[1])])
      .nice()
      .range([height, 0]);

    // Create tooltip
    const tooltip = d3
      .select('body')
      .append('div')
      .attr('class', 'tooltip')
      .style('position', 'absolute')
      .style('padding', '8px')
      .style('background', '#ddd')
      .style('border-radius', '4px')
      .style('visibility', 'hidden');

    // Draw bars
    svg
      .selectAll('rect')
      .data(categorySales)
      .enter()
      .append('rect')
      .attr('x', (d) => xScale(d[0]))
      .attr('y', (d) => yScale(d[1]))
      .attr('width', xScale.bandwidth())
      .attr('height', (d) => height - yScale(d[1]))
      .attr('fill', 'teal')
      .on('mouseover', (event, d) => {
        tooltip
          .style('visibility', 'visible')
          .html(
            `<strong>Category:</strong> ${d[0]}<br><strong>Sales:</strong> $${d[1]}`
          );
      })
      .on('mousemove', (event) => {
        const [x, y] = d3.pointer(event);
        tooltip.style('top', `${y}px`).style('left', `${x + 20}px`);
      })
      .on('mouseout', () => {
        tooltip.style('visibility', 'hidden');
      });

    // Add value labels at the top of each bar
    svg
      .selectAll('text.label')
      .data(categorySales)
      .enter()
      .append('text')
      .attr('class', 'label')
      .attr('x', (d) => xScale(d[0]) + xScale.bandwidth() / 2)
      .attr('y', (d) => yScale(d[1]) - 5)
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .text((d) => `$${d[1]}`);

    // X-axis
    svg
      .append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(xScale))
      .selectAll('text')
      .attr('transform', 'rotate(-45)')
      .style('text-anchor', 'end');

    // Y-axis
    svg.append('g').call(d3.axisLeft(yScale));
  }, [data]);

  return <svg ref={chartRef}></svg>;
};

export default BarChart;
