// frontend/src/components/LineChart.js
import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const LineChart = ({ data }) => {
  const chartRef = useRef();

  useEffect(() => {
    // Clear previous elements
    d3.select(chartRef.current).selectAll('*').remove();

    const width = 600;
    const height = 300;
    const margin = { top: 20, right: 30, bottom: 40, left: 50 };

    const svg = d3
      .select(chartRef.current)
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Prepare the data by month and convert month names to proper order
    const monthlySales = d3.rollups(
      data,
      (v) => d3.sum(v, (d) => d.sales),
      (d) => d.month
    );

    // Sort data by month order (assuming data is for a single year)
    const monthOrder = [
      'January', 'February', 'March', 'April', 'May', 'June', 
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    monthlySales.sort((a, b) => monthOrder.indexOf(a[0]) - monthOrder.indexOf(b[0]));

    const xScale = d3
      .scalePoint()
      .domain(monthlySales.map((d) => d[0]))
      .range([0, width]);

    const yScale = d3
      .scaleLinear()
      .domain([0, d3.max(monthlySales, (d) => d[1])])
      .nice()
      .range([height, 0]);

    // Create a line generator
    const line = d3
      .line()
      .x((d) => xScale(d[0]))
      .y((d) => yScale(d[1]))
      .curve(d3.curveMonotoneX);

    // Draw the line
    svg
      .append('path')
      .datum(monthlySales)
      .attr('fill', 'none')
      .attr('stroke', 'blue')
      .attr('stroke-width', 2)
      .attr('d', line);

    // Add data points
    svg
      .selectAll('circle')
      .data(monthlySales)
      .enter()
      .append('circle')
      .attr('cx', (d) => xScale(d[0]))
      .attr('cy', (d) => yScale(d[1]))
      .attr('r', 4)
      .attr('fill', 'red');

    // Tooltip
    const tooltip = d3
      .select('body')
      .append('div')
      .attr('class', 'tooltip')
      .style('position', 'absolute')
      .style('padding', '8px')
      .style('background', '#ddd')
      .style('border-radius', '4px')
      .style('visibility', 'hidden');

    // Add mouse events for tooltips
    svg
      .selectAll('circle')
      .on('mouseover', (event, d) => {
        tooltip
          .style('visibility', 'visible')
          .html(
            `<strong>Month:</strong> ${d[0]}<br><strong>Sales:</strong> $${d[1]}`
          );
      })
      .on('mousemove', (event) => {
        const [x, y] = d3.pointer(event);
        tooltip.style('top', `${y}px`).style('left', `${x + 20}px`);
      })
      .on('mouseout', () => {
        tooltip.style('visibility', 'hidden');
      });

    // Add labels for each data point
    svg
      .selectAll('text.label')
      .data(monthlySales)
      .enter()
      .append('text')
      .attr('class', 'label')
      .attr('x', (d) => xScale(d[0]))
      .attr('y', (d) => yScale(d[1]) - 10)
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .text((d) => `$${d[1]}`);

    // X-axis
    svg
      .append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(xScale))
      .selectAll('text')
      .attr('transform', 'rotate(-45)')
      .style('text-anchor', 'end');

    // Y-axis
    svg.append('g').call(d3.axisLeft(yScale));
  }, [data]);

  return <svg ref={chartRef}></svg>;
};

export default LineChart;
