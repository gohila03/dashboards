// frontend/src/App.js
import React, { useState, useEffect } from 'react';
import api from './Api.js';
import LineChart from './components/LineChart';
import BarChart from './components/BarChart';
import PieChart from './components/PieChart';
import './App.css';

const App = () => {
  const [selectedChart, setSelectedChart] = useState('line');
  const [salesData, setSalesData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await api.get('/');
      setSalesData(response.data);
    };
    fetchData();
  }, []);

  const handleChartChange = (chart) => {
    setSelectedChart(chart);
  };

  return (
    <div className="App">
      <header className="header">
        <h1>Sales Dashboard</h1>
        <h2>Navigate the data with Pie Chart, Bar Chart, and Line Chart</h2>
      </header>

      <nav className="navbar">
        <button
          onClick={() => handleChartChange('line')}
          className={selectedChart === 'line' ? 'active' : ''}
        >
          Line Chart
        </button>
        <button
          onClick={() => handleChartChange('bar')}
          className={selectedChart === 'bar' ? 'active' : ''}
        >
          Bar Chart
        </button>
        <button
          onClick={() => handleChartChange('pie')}
          className={selectedChart === 'pie' ? 'active' : ''}
        >
          Pie Chart
        </button>
      </nav>

      <div className="chart-container">
        {selectedChart === 'line' && <LineChart data={salesData} />}
        {selectedChart === 'bar' && <BarChart data={salesData} />}
        {selectedChart === 'pie' && <PieChart data={salesData} />}
      </div>
    </div>
  );
};

export default App;
